const express = require('express');
const todomodel = require('../models/todomodels.js');

// const getall = (req,res)=>{
//     todomodel.find()
//     .then(response => res.send(response))
//     .catch(err => {
//         console.log("cannot get");
//         res.status(500).send("fail to getting documents")
//     })
// }
const getall = async (req, res) => {
    try {
    await todomodel.find()
            .then(response => res.send(response))
            .catch(err => {
                console.log("cannot get",err);
                res.status(500).send("fail to getting documents")
            })
    } catch (error) {
        console.error("Error retrieving data:", error);
        res.status(500).send("Internal Server Error");
    }
}


// const saveall = (req,res)=>{
//     let data = new todomodel(req.body);
//     data.save()
//     .then(()=>res.status(200).send("document saved"))
//     .catch(()=>{
//         console.log("fail to save")
//         res.status(500).send("fail to save, try again")
//     })
//   }
const saveall = async (req, res) => {
    try {
        let data = new todomodel(req.body);
          await data.save()
            .then(()=>res.status(200).send("document saved"))
            .catch(()=>{
                console.log("fail to save")
                res.status(500).send("fail to save, try again")
            })
    } catch (error) {
        console.error("Error retrieving data:", error);
        res.status(500).send("Internal Server Error");
    }
}

module.exports = {getall,saveall};