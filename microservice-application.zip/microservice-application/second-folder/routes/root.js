const express = require('express');
//const todomodel = require('../models/todomodels.js');
const {getall,saveall} = require('../service/response-handler.js');

const routes = express.Router();

// routes.get('/data',(req,res)=>{
//     todomodel.find()
//     .then(response => res.send(response))
//     .catch(err => {
//         console.log("cannot get");
//         res.status(500).send("fail to getting documents")
//     })
// });

routes.get('/data',getall)

// routes.post('/data',(req,res)=>{
//     let data = new todomodel(req.body);
//     data.save()
//     .then(()=>res.status(200).send("document saved"))
//     .catch(()=>{
//         console.log("fail to save")
//         res.status(500).send("fail to save, try again")
//     })
// });

routes.post('/data',saveall)

module.exports = routes