const mongoose = require('mongoose');

const Schema = mongoose.Schema;
let objectid = mongoose.Schema.ObjectId;

let todomodel = mongoose.model("todomodel", new Schema({
    name : {
        type : String,
        required : true
    }
}));

module.exports = todomodel;