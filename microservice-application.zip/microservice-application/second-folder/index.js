const express = require('express');
const mongoose = require('mongoose');
const config = require('./config.json');
// const todomodel =require('../models/todomodels');
const root = require('./routes/root')

let app = express();

app.use(express.json())
app.use(express.static(__dirname))
app.use(root)


let urlString ='';
let url = urlString.concat(config.db).concat(":").concat(config.host).concat(":").concat(config.port)

mongoose.connect(url)
.then(()=>{console.log("Database connected succesfully")})
.catch(err =>{console.log("error occured",err)})



app.listen(8001,'localhost',(err)=>{
    console.log("server is runnig on localhost:8001")
})