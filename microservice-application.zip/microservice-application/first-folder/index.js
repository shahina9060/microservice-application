const express = require('express');
//const todo = require('./second-folder');
const {getall,saveall} = require('../second-folder/service/response-handler.js');
//const {getall,saveall} = require('../second-folder/routes/root.js')
let app = express();

// app.use(express.static(__dirname));
app.use(express.json());
app.use(express.urlencoded({extended: true}));


app.get('/todo',getall);
app.post('/todo',saveall);

// app.listen(8000,"localhost",(err)=>{
//     console.log("server is running on localhost:8000")
// });
app.listen(8000, () => {
    console.log("Server is running on port 8000");
});